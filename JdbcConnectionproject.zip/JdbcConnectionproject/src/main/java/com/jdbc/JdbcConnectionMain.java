package com.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcConnectionMain{

	public static void main(String[] args) {
		//Connection
		//1.Load the driver
		//make the connection
		//create a statement
		//execute the query
		String driver = "com.mysql.cj.jdbc.Driver";
		String un = "root";
		String pass = "root";
		String url = "jdbc:mysql://localhost:3306/malathidatabase";
		
		try {
			Class.forName(driver); //1.load the driver
			//2. make a connection
			Connection con = DriverManager.getConnection(url,un,pass);
			Statement stmt = con.createStatement();
			
			String s = "select * from employee";
			
			ResultSet rs = stmt.executeQuery(s);
			
			System.out.println("eid\tename\telary\tedeptment");
			while(rs.next()) {
				
				System.out.println(rs.getInt("eid")+"\t"+rs.getString("ename")+"\t"+rs.getInt("elary")+"\t"+rs.getString("edeptment"));
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
     }

}




