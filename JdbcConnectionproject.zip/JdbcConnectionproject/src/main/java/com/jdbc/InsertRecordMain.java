package com.jdbc;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class InsertRecordMain {

	public static void main(String[] args) {
		//make a connections
		String driver="com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/malathidatabase";
		String un = "root";
		String pass = "root";
		int employeeid;
		String employeename;
		float employeesalary;
		String employeedepartment;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter employee name");
		employeename=sc.nextLine();
		System.out.println("Enter employee id");
		employeeid=sc.nextInt();
		System.out.println("Enter employee salary");
		employeesalary=sc.nextFloat();
		System.out.println("Enter employee department");
		employeedepartment=sc.next();
		try {
			Class.forName(driver);
			Connection con = DriverManager.getConnection(url, un, pass);
			Statement st = con.createStatement();
			
			String select = "select * from employee where eid="+employeeid;
		    ResultSet rs = st.executeQuery(select);	
		
		    if(!rs.next()) {
			
		String insert = "insert into employee values("+employeeid+",'"+employeename+"',"+employeesalary+",'"+employeedepartment+"')";
		//System.out.println("insert="+insert);
		System.out.println(insert);
			
			    int i = st.executeUpdate(insert);
			    
			    if(i>0) {
			    	System.out.println("Record is inserted successfully");
			    }
			    else {
			    	System.out.println("Record is not inserted successfully");
			    }
		    }
		    else {
		    	System.out.println(employeeid+" already exist");
		    }
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}

