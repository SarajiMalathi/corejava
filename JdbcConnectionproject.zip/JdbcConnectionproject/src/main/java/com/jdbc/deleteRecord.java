package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class deleteRecord {

	public static void main(String[] args) {
		
			String driver="com.mysql.cj.jdbc.Driver";
			String url="jdbc:mysql://localhost:3306/malathidatabase";		String un="root";
			String pw="root";
			String un1="root";
			Scanner sc=new Scanner(System.in);
			int empid = 0;
			//String empname = null;
			//float empsalary;
			//String empdepartment;
			try {
				Class.forName(driver);
				Connection con=DriverManager.getConnection(url,un1,pw);
				Statement st=con.createStatement();
				//System.out.println("enter employee name");
				//empname=sc.nextLine();
				System.out.println("enter employee id");
				empid=sc.nextInt();
				//System.out.println("enter employee salary");
			//empsalary=sc.nextFloat();
				//System.out.println("enter employee department");
				//empdepartment=sc.nextLine();
				
				
				String select="select * from employee where eid="+empid;
				ResultSet rs=st.executeQuery(select);
				if(rs.next()) {
				String delete="delete from employee  where eid="+empid;
				System.out.println(delete);
				int retval=st.executeUpdate(delete );
				if(retval>0) {
					System.out.println("record is deleted");
				}
				else {
					System.out.println("record is not deleted");
				}
				
			
		
				}else {
					System.out.println(empid+"not exist in deleted");
				}
			}
		catch(Exception e) {
			e.printStackTrace();

		}
			
		}
		}
		
					
				
				
				
			 

