package edu.com;
		import java.util.function.*;
		public class FunctionDemo{
		     public static void main(String args[]){
		        Function<String, Integer> fn=(str)->str.length();
		        
		        String s = "Malathi";
		        System.out.println("Number og character in string "+fn.apply(s));
		     }



	}


