package edu.com;
import java.util.function.Predicate;

public class predicateDemo {

	public static void main(String[] args) {
		
			
			Predicate<Integer> pob=(i)->(i>20);//Functional programming
			//call call Predicate , in predicate we have a method test
			boolean b=pob.test(5);
			System.out.println(b);
			



	}

}
