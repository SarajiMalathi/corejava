package edu.com;
interface StringDisplay{
	void strDisplay(String s);

}


public class LambdaWithArgu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringDisplay obj=(s)->{
			System.out.println("Hello "+s);
		};
		obj.strDisplay("Malathi");
	}





	}


