package edu.com;

import java.util.ArrayList;
import java.util.Iterator;

public class Arraylistlambda {

	public static void main(String[] args) {
		ArrayList<Integer> arraylist=new ArrayList<Integer>();
		for(int i=100;i<=120;i++) {
			arraylist.add(i);
		}
		System.out.println(arraylist);
		Iterator<Integer> it=arraylist.iterator();
		while(it.hasNext());
		{
			System.out.println(it.next());
		
		}
		arraylist.forEach(element->System.out.println(element));

	}

}
