

package edu.com;


public class LambdaExpression {

	public static void main(String[] args) {
		
		/*ThreadClass tob=new ThreadClass();
		Thread t=new Thread(tob);
		t.start();*/
		
		//Inner class
		Runnable rob=new Runnable() {
			
			@Override
			public void run() {
				System.out.println("run method");
				
			}
		};
		Thread t=new Thread(rob);
		t.start();
		
		
		//Lambda expression : it is applied to functional interface
		                     //interface which has only abstract method
		                   //()->
		Runnable robj=()->{
			System.out.println("run method is called");
			System.out.println("another statement");
		};
	       Thread tobj=new Thread(robj);
          tobj.start();
	}

}
