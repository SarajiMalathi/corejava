package edu.com;
@FunctionalInterface
interface MyDisplay{
	void display();
}

public class LambdaNoArgu {

	public static void main(String[] args) {
		MyDisplay obj=()->
			System.out.println("display method of interface");
		obj.display();
		}
	}



		

	


