package edu.com;
@FunctionalInterface
interface Subtraction{
	int sub(int a, int b);
	
}



public class Lambdawithargureturn {

	public static void main(String[] args) {
		Subtraction obj=(a,b)->(a-b);
		int sub=obj.sub(10,20);
		System.out.println("difference="+sub);
	}

}
