package edu.com;
interface Addition{
	void add(int a,int b);
		
	}


public class Lambdawithargnoreturn {

	public static void main(String[] args) {
		Addition obj= (int a,int b)->{
			int s;
			s=a+b;
			System.out.println("the sum of two nos"+s);
		};
		obj.add(10,20);
			
			
		
	}

}
