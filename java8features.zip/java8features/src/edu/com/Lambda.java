package edu.com;
interface Myinterface{
	void display();
	default void fun1() {
		System.out.println("default method");
	}
	
}
 class MyClass implements Myinterface{
	public void display() {
		System.out.println("display method");
	}
}

public class Lambda {

	public static void main(String[] args) {
	MyClass ob=new MyClass();
	ob.display();
	ob.fun1();
	

	}

}
