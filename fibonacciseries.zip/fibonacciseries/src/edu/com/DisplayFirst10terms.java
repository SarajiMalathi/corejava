package edu.com;


public class DisplayFirst10terms {

	public static void main(String[] args) {
		int num;
		for(int i=0;i<=100;i=i+10) {
			System.out.println("display first 10 numbers");
			
		}
		
		

	}

}
