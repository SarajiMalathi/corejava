package edu.com;

import java.util.Scanner;

public class SearchingArray {

	public static void main(String[] args) {
		int arr[]=new int[6];
		int key,pos=-1;
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter array size");
		size=sc.nextInt();
		arr=new int[size];
		System.out.println("enter array elements");
		
		
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("enter key elements");
		key=sc.nextInt();
		
		for(int i=0;i<arr.length;i++)
		{
			if(key==arr[i]) {
				pos=i;
				break;
			}
		}
		if(pos>0){
			System.out.println("successful search");
			System.out.println("key+ found at position"+(pos+1));
		}
		else {
			System.out.println(key+"not found");
			System.out.println("unsuccessful search");
		}
	}
	
			
				
		
		
		

	}


