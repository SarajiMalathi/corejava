package edu.com;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		int num,i,f1,f2,f3;
		f1=1;
		f2=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a no.of terms");
		num=sc.nextInt();
		System.out.println("fibonacci series");
		System.out.println(f1);
		System.out.println(f2);
		for(i=3;i<=num;i++)
		{
			f3=f2+f1;
			System.out.println(f3);
			f1=f2;
			f2=f3;
			
			
		}
		
				

	}

}
