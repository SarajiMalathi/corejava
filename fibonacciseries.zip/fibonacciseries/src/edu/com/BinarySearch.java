package edu.com;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int arr[];
		int low,high,mid=0,n,key;
		int pos=-1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size array");
		n=sc.nextInt();
		arr=new int[n];
		System.out.println("enter array element in ascending order");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("enter key elements");
		key=sc.nextInt();
		low=0;
		high=n-1;
		while(low<=high)
		{
			mid=(low+high)/2;
			if(arr[mid]==key)
			{
				pos=mid;
				break;
			}
			else if(key<arr[mid])
			{
				high=mid-1;
			}
			else {
				low=mid+1;
			}
		}
		if(pos>=0)
		{
			System.out.println("successful search");
			System.out.println(key+"found at position"+(mid+1) );
		}
		else {
			System.out.println("unsuccessful search");
			System.out.println(key+"not found");
		}
	}
	
				
				
			
			
			
		}
		

	

