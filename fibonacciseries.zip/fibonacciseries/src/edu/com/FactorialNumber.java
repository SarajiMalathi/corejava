package edu.com;

import java.util.Scanner;

public class FactorialNumber {

	public static void main(String[] args) {
		int num,fact=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		num=sc.nextInt();
		for( int i=num;i>=1;i--)
		{
			fact=fact*i;
			System.out.println("factorial of number is"+fact);
			
		}
		
		
		

	}

}
