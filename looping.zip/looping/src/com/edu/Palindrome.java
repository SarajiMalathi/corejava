package com.edu;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
	int num,rev,digit,num1;
	rev=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number");
	num=sc.nextInt();
	num1=num;
	while(num>0)
	{
		digit=num%10;
		rev=rev*10+digit;
		num=num/10;}
	
		if(num1==rev) {
			System.out.println("the number is palindrome");
		}
		else {
			System.out.println("the number is not a palindrome");
			
			
		
	}
	
	

	}

}
