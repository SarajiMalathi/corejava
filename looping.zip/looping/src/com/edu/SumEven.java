package com.edu;

public class SumEven {

	public static void main(String[] args) {
		int i,sum;
		sum=0;
		i=2;
		while(i<=100) {
			sum=sum+i;
			i=i+2;
			System.out.println("the sum of even"+sum);
			
		}

	}

}
