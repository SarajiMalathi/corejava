package com.edu;

public class IneDre {

	public static void main(String[] args) {
		int a,b;
		a=10;
		b=++a;
		System.out.println("a"+a);
		System.out.println("b"+b);
		

	}

}
