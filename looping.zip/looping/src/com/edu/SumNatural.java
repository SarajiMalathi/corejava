package com.edu;

public class SumNatural {

	public static void main(String[] args) {
		int i,sum;
		i=1;
		sum=0;
		while(i<=100)
		{
			sum=sum+i;
			i=i+1;
			System.out.println("sum "+sum);
			
		}
	

	}

}
