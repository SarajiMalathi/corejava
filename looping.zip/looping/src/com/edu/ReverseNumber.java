package com.edu;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		int num,digit,rev=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("ente number");
		num=sc.nextInt();
		while(num>0)
		{
			digit=num%10;
			System.out.print(digit);
			num=num/10;
			rev=rev*10+digit;
			System.out.println("reverse of nmber"+rev);
		}
		
		
				
		

	}

}
