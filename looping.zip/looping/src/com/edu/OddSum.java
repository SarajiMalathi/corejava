package com.edu;

public class OddSum {

	public static void main(String[] args) {
		int i,sum;
		i=1;
		sum=0;
		while(i<=99)
		{
			sum=sum+i;
			i=i+1;
			System.out.println("the sum odd"+sum);
		}

	}

}
