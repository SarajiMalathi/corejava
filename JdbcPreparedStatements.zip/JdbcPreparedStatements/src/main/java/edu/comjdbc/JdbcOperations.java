package edu.comjdbc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class JdbcOperations {
	static Connection connection;
	static Scanner sc;
	static ResultSet rs;
	static PreparedStatement pst;
	private static int retval;
	public static void displayRecord() throws SQLException {
		connection=DatabaseConnectionJDBC.getConnection();
		String select="select * from employee";
		pst=connection.prepareStatement(select);
		rs=pst.executeQuery();
		System.out.println("empid \t empname \t empsalary \t empdepartment");
		
			while(rs.next()) {
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getFloat(3)+"\t"+rs.getString(4)+"\t");
			}
			}
		
		public static void addRecord() throws SQLException {
		connection=DatabaseConnectionJDBC.getConnection();
		sc=new Scanner(System.in);
		System.out.println("enter employee name");
		String name=sc.nextLine();
		System.out.println("enter employee id");
		int id=sc.nextInt();
		System.out.println("enter employee salary");
		float salary=sc.nextFloat();
		System.out.println("enter employee department");
		String department=sc.next();
		String sql="select * from employee where eid=?";
		pst=connection.prepareStatement(sql);
		pst.setInt(1,id);
		rs=pst.executeQuery();
		if(!rs.next()) {
			String insert="insert into employee values(?,?,?,?)";
			pst=connection.prepareStatement(insert);
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setFloat(3, salary);
			pst.setString(4, department);
			if(retval>0)
			{
				System.out.println("record is added");
			}
			else {
				System.out.println("error occured");
			}
		}
			else {
				System.out.println("id already exists");
			}
		
		}
		public static void updateRecord() throws SQLException {
		connection= DatabaseConnectionJDBC.getConnection();
		sc=new Scanner(System.in);
		System.out.println("enter name to change");
		System.out.println("enter id");
		String name = sc.next();
		int id = sc.nextInt();
		String select = "select * from employee where eid=?";
		pst=connection.prepareStatement(select);
		pst.setInt(1,id);
		rs=pst.executeQuery();
		if(rs.next()) {
			String update="update employee set ename=? where eid=?";
			pst=connection.prepareStatement(update);
			pst.setString(1, name);
			pst.setInt(2, id);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("record is updated");
			}else {
				System.out.println("error occured");
			}}
		else {
				System.out.println("record not exists");
			}
		}
		public static void deleteRecord() throws SQLException {
		connection=DatabaseConnectionJDBC.getConnection();
		sc=new Scanner(System.in);
		System.out.println("enter id");
		int id = sc.nextInt();
		String select="select * from employee where eid=?";
		pst=connection.prepareStatement(select);
		pst.setInt(1,id);
		rs=pst.executeQuery();
		if(rs.next()) {
			String delete="delete from employee where eid=?";
			pst=connection.prepareStatement(delete);
			pst.setInt(1, id);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("record deleted");
			}else {
				System.out.println("error deleted");
			}}
		}
}

		

		
	
				
		

		
		
	

			






