package edu.com;
import java.util.Scanner;

class Student5{
	private int sid;
	private String sname;

	public Student5() {
		sid=0;
		sname=null;
	}
	Student5(int sid, String sname){
		this.sid=sid;
		this.sname=sname;
	}
	
	void student5Display() {
		System.out.println("Id="+sid);
		System.out.println("Name="+sname);
	}
	public void inputData() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		sname=sc.nextLine();
		System.out.println("Enter id");
		sid=sc.nextInt();
	}
}
public class StudentMain {

	public static void main(String[] args) {
		Student5 s1=new Student5(100,"chitti"); 
		Student5 s2=new Student5(101,"malathi");
          s1.student5Display();
          s2.student5Display();
          
          Student5 s3=new Student5();
          s3.inputData();
          s3.student5Display();
	}




	}


