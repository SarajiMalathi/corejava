package edu.com.inheritance;
class parent1{
	parent1(){
		System.out.println("parent constructor");
	}
}
class Child1 extends parent1{
	Child1(){
		System.out.println("child1 constructor");
	}
}

public class ConstructorParentChildMain {

	public static void main(String[] args) {
		Child1 c=new Child1();
	}
	

}
