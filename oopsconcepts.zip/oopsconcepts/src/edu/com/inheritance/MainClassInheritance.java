package edu.com.inheritance;
class parent{
	private int i;
	public int j;
	int k;
	private void method1() {
		System.out.println("private method privatedata"+i);
		
	}
	public void displaydata() {
		System.out.println("displaydata method of parent class");
		method1();
		
	}
}
class child extends parent{
	void display() {
		
		System.out.println("j="+j);
		System.out.println("k="+k);
	}
	public void displaydata(){
		System.out.println("displaydata function of child class");
		
	}
	
  
	
}

public class MainClassInheritance {

	public static void main(String[] args) {
		child cobj=new child();
		cobj.display();
		cobj.displaydata();
	}
	
		
	
	}


