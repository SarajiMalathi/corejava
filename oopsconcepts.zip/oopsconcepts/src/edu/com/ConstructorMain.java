package edu.com;
class Student{
	int sid;
	String sname;
	float sfee;

Student(){
	System.out.println("constructor");
	sid=2;
	sname="malathi";
	sfee=1000;
	
}
	
}

public class ConstructorMain {

	public static void main(String[] args) {
		int totalfee;
		Student sobj=new Student();
		System.out.println("sid="+sobj.sid);
		System.out.println("sname="+sobj.sname);
		System.out.println("sfee="+sobj.sfee);
		
		

	}

}
