package edu.com;
import java.util.Scanner;
class Square{
	int side,area;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("side of square");
		side=sc.nextInt();
	}
	void calculateArea() {
		area=side*side;
	}
	void displayArea() {
		System.out.println("the area of square"+area);
		
	}
}

public class MainclassSquare {

	public static void main(String[] args) {
		System.out.println(" you are in main method");
		Square sobj=new Square();
		sobj.input();
		sobj.calculateArea();
		sobj.displayArea();
		
		

	}

}
