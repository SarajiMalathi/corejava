package edu.com;
import java.util.Scanner;
class Circle
{
	float radius,area;
	
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("radius of circle");
		radius=sc.nextInt();
	}
	void calculateArea(){
		area=3.141f*radius*radius;
	}
	void displayArea() {
		System.out.println("area of radius"+area);
		

	
		
		
	}
	
}

public class MainClassCircle {

	public static void main(String[] args) {
		System.out.println("you are in main method");
		Circle cobj=new Circle();
		cobj.input();
		cobj.calculateArea();
		cobj.displayArea();
		
		
		
	}

}
