package edu.com;
import java.util.Scanner;
class rectangle{
	int length,breadth,area;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("length and breadth of rectangle");
		length=sc.nextInt();
		breadth=sc.nextInt();
	}
	void calculateArea() {
		area=length*breadth;
	}
	void displayArea() {
		System.out.println("area of rectangle of length= "+length+" & breadth= "+breadth+" is " +area);
		
		
				
	}
}

public class MainclassRectangle {

	public static void main(String[] args) {
		System.out.println("you are in main method");
		rectangle robj=new rectangle();
		robj.input();
		robj.calculateArea();
		robj.displayArea();
	}


	
		
		
	}


