package edu.com.poly;
class AreaCalculation{
	public void area(int side) {
		int area=side*side;
		System.out.println("area of square"+area);
		
}
	public void area(int length,int breadth) {
		int area=length*breadth;
		System.out.println("area of rectangle"+area);
	}
	public void area(float radius) {
		float area=3.141f*radius*radius;
		System.out.println("area of circle"+area);
	}
	public void area(float base,float height) {
		float area=0.5f*base*height;
		System.out.println("area of triangle"+area);
	}
}


public class AreaCalculationMain {

	public static void main(String[] args) {
		AreaCalculation obj=new AreaCalculation();
		obj.area(10);
		obj.area(10,20);
		obj.area(3.0f);
		obj.area(3.0f,3.5f);
		
		 

	}

}
