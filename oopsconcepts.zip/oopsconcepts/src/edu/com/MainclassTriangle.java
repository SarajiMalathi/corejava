package edu.com;
import java.util.Scanner;
class Triangle{
	float base,height,area;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("base and height of triangle");
		base=sc.nextInt();
		height=sc.nextInt();
	}
	void calculateArea() {
		area=0.5f*base*height;
	}
	void displayArea() {
		System.out.println("area of triangle of base="+base+" & height="+height+" is "+area);
		
	
	}
}

public class MainclassTriangle {

	public static void main(String[] args) {
		System.out.println("you are in main method");
		Triangle tobj=new Triangle();
		tobj.input();
		tobj.calculateArea();
		tobj.displayArea();
		

	}

}
