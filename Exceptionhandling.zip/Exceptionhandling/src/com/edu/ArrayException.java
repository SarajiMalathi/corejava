package com.edu;

import java.util.Scanner;

public class ArrayException {

	public static void main(String[] args) {
		int arr[]=new int[5];
		System.out.println("enter five elements of array");
		Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("array elements are:");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
			try {
				System.out.println(arr[5]);
			}
			catch(ArrayIndexOutOfBoundsException e) {
				e.printStackTrace();
				
				
			}
			
			
			
			
		}
	}

}
