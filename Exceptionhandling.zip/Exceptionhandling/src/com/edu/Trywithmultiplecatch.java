package com.edu;

public class Trywithmultiplecatch {

	public static void main(String[] args) {
		int a=10,b=2,c=0;
		int arr[]=new int[5];
		System.out.println("stating point");
		try {
			c=a/b;
			arr[5]=20;
			
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
			
		}
		catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			
		}
		System.out.println("ending point");


	}

}
