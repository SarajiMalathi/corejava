package com.edu;

import java.util.Scanner;

public class ArithmaticDivision {

	public static void main(String[] args) {
		int a,b,c=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 2 numbers");
		a=sc.nextInt();
		b=sc.nextInt();
		try {
			c=a/b;
		}
		
		catch(ArithmeticException e) {
			e.printStackTrace();
		}
			
			
			
			
		
		System.out.println("enter division"+c);
		
		
	}

}
