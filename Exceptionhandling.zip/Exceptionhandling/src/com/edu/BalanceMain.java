package com.edu;


import java.util.Scanner;
 class BankExcception extends Exception {
    public BankExcception(String s) {
  	  super(s);
    }
}

class Bank{
	private float amount;
	
	public Bank(int amount) {
		this.amount=amount;
	}
	public void depositAmount(float damount) {
		System.out.println("Your Balance ="+amount);
		amount=amount+damount;
		System.out.println("Amount is deposited your balance="+amount);
	}
	
	public void withdrawAmout(float wamount) {
		System.out.println("Before withdraw amount="+amount);
		if(wamount>amount) {
			try {
				throw new BankExcception("Infufficient Balance");
			}catch(BankExcception e) {
				e.printStackTrace();
			}
			
		}else {
			amount=amount-wamount;
			System.out.println("After withdraw your balance="+amount);
		}
	}
	
}

public class BalanceMain {

	public static void main(String[] args) {
		//MENU Driven program using switch case
		Bank bankobj=new Bank(1000);
		Scanner sc = new Scanner(System.in);
		int ch;
		float da, wa;
		while(true) {  //infinite while  or for(;;) infinite for
		System.out.println("Bank Options");
		System.out.println("1.DEPOSIT");
		System.out.println("2.WITHDRAW");
		
		System.out.println("Enter your choice");
		ch=sc.nextInt();
		
		switch(ch) {
		case 1:System.out.println("Enter the amount to deposit");
		         da=sc.nextFloat();
		         bankobj.depositAmount(da);
		         break;
		case 2:System.out.println("Enter amount to withdraw");
		           wa=sc.nextFloat();
		           bankobj.withdrawAmout(wa);
		           break;
		
		 
		}
		System.out.println("Do you want to continue , yes/no");
		
	     String option=sc.next();
	     if(option.equalsIgnoreCase("no")) {
	    	 System.exit(0);
	     }
	}
 }
}
