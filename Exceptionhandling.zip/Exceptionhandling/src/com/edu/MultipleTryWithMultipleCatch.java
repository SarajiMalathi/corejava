package com.edu;

public class MultipleTryWithMultipleCatch {

	public static void main(String[] args) {
		int a=10,b=0,c=1;
		int arr[]=new int[5];
		String s=null;
		System.out.println("stating point");
		try {
			c=a/b;
			
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
		}
		try {
			arr[5]=20;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		try {
			c=s.length();
		}
		catch(NullPointerException e) {
			e.printStackTrace();
		}
		finally {
			System.out.println("final block executed");
		}
		System.out.println("ending point");
	}
	
			
			
			
			
			
		
		
	
	}


