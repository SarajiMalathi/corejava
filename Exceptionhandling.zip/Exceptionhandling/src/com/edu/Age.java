package com.edu;
import java.util.Scanner;
public class Age {
	public static void main(String[] args) {
		String name;
		int age;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter age ");
		age=sc.nextInt();
		if(age>=10&& age<=20) {
				System.out.println(" room no A is eligible");
				
			}
			 if (age>20&& age<=30) {
				System.out.println("room no b is eligible");
			}
			 if(age>30) {
				System.out.println("room no c eligible");
			 }
			 if(age<10){
				 System.out.println("not eligible");
			 }
	}
}


			
	
		
			
			
		
		
	


