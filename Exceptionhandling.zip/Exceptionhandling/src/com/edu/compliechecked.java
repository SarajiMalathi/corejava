package com.edu;
//Example for CheckedException



import java.io.BufferedReader;  
import java.io.IOException;
import java.io.InputStreamReader;

class Product{ 
	private int prodid;
	private String prodname;
	
	public void inputData() throws IOException {
		
		InputStreamReader  inputstreamreader= new InputStreamReader(System.in);
	
		BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
		
			
			System.out.println("Enter product name");
		prodname = bufferedreader.readLine(); //checked exception
		 System.out.println("Enter Product Id");
		 prodid= Integer.parseInt(bufferedreader.readLine());
		
		
		
	}
	
	public void displayProduct() {
		System.out.println("Product Name="+prodname);
		System.out.println("Product Id="+prodid);
	}
	
}


public class compliechecked{
	


	public static void main(String[] args) throws IOException {
		System.out.println("Hello");
		Product product=new Product();
		product.inputData();
		product.displayProduct();
	}


	
	}


