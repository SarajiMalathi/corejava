package com.edu;

import java.util.Scanner;
class AgecheckvoteException extends Exception{
	public AgecheckvoteException(String s) {
		super(s);
		
	}
}

class Agecheckvote{
	private int age;
	public void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter age");
		age=sc.nextInt();
	}
	
		public void checkEligibility() {
			if(age<18) {
				try {
					
					throw new AgecheckvoteException("age is less than 18 not eligible");
				}
				catch(AgecheckvoteException exobj) {
					exobj.printStackTrace();
				}
			}
			else {
				System.out.println("eligible");
				
			
	
					
			}
			
			
		}
	
	}




public class Agecheck {

	public static void main(String[] args) {
		Agecheckvote a=new Agecheckvote();
		a.inputData();
		a.checkEligibility();
		
	}

}
