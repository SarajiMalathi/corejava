package com.edu;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		int num,sum,digit,k;
		sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		num=sc.nextInt();
		k=num;
		while(sum==k)
		{
			digit=num%10;
			num=num/10;
			sum=sum+(digit*digit*digit);
		}
		if(sum==k)
		{
			System.out.println("the number is an armstrong");
		}
		else
		{
			System.out.println("the number is not");
		}
		
		}
				
		
		

	}


