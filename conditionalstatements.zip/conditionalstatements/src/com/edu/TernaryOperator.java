package com.edu;

import java.util.Scanner;

public class TernaryOperator {

	public static void main(String[] args) {
	int a,b,lar;
	Scanner sc=new Scanner(System.in);
	System.out.println("ener first number");
	a=sc.nextInt();
	System.out.println("enter the second number");
	b=sc.nextInt();
	lar=(a>b)?a:b;
	System.out.println("the largest of "+a+" and "+b+" is "+lar);

	}

}
