package com.edu;

import java.util.Scanner;

public class BankApplication {

	public static void main(String[] args) {
		float amount,withdrawamount,depamount;
		amount=1000;
		int choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("----menu---");
		System.out.println(" enter depamount");
		System.out.println("enter withdrawamount");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			withdrawamount=sc.nextFloat();
			if(withdrawamount>amount)
			{
				System.out.println("enter amount of withdrawamount"+amount);
				
			}
			else
			{
				amount=amount-withdrawamount;
				System.out.println("balance of amount after withdrawamount"+amount);
				
			}
			break;
			default:
				System.out.println("invalid");
				break;
		}
	}
}
			
			
			
			
			
			
		
		

	


