package com.edu;
import java.util.Scanner;


public class Divisibility{

	public static void main(String[] args) {
		int num;
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		if(num%3==0&&num%5==0)
		{
			System.out.println("the number is divisibility  3 and 5");
		}
		else if(num%3==0) {
			System.out.println("the number is  divisibility by3"+num);
		}
		else if(num%5==0)
		
		{
			System.out.println("the number is divisibility by 5"+num);
	
		}
		else
		{
			System.out.println("the number is not divisibility by 3 and 5");
	
		}
	}
}



		