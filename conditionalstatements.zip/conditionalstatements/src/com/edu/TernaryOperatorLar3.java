package com.edu;
import java.util.Scanner;


public class TernaryOperatorLar3{
	static void main(String[] args) {
		int num1,num2,num3,lar;
		Scanner sc=new Scanner(System.in);
		System.out.print("enter 3 numbers");
		num1=sc.nextInt();
		num2=sc.nextInt();
		num3=sc.nextInt();
		lar=(num1>num2&&num1>num3)?num1:(num2>num3&&num2>num1)?num2:num3;
		System.out.println("largest of "+num1+","+num2+","+num3+" is "+lar);
	}
	

	}


		

	


