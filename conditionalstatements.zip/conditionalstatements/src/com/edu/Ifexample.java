package com.edu;
import java.util.Scanner;

public class Ifexample {

	public static void main(String[] args) {
	int num;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number");
	num=sc.nextInt();
	if(num==0) {
		System.out.println("the entered number is zero");
	}
	else {
		System.out.println("the entered number is not equal to zero");
	}
	sc.close();

	}

}
