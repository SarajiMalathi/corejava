package com.edu;

public class Fahrentocelsius {
	public double fahrenheitToCelsius(double fahrenheit) {
		double celsius=((fahrenheit-32)*0.55556);
		
		return celsius;
		
	}

}
