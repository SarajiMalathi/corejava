package com.edu;

public class LargestThreeNumbers {
	public int largestNumberThree(int n1,int n2,int n3) {
		int l=(n1>n2&&n1>n3)?n1:(n2>n1&&n2>n3)?n2:n3;
		return l;
		
		
	}

}
