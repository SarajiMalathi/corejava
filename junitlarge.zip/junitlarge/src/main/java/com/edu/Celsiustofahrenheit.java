package com.edu;

public class Celsiustofahrenheit{
	public double celsiusToFahrenheit(double celsius) 
	{
		double fahrenheit=((1.8*celsius)+32);
		return fahrenheit;}
	
	
		


}
