package com.edu;

public class VowelCount {
	int vc;
	public  int vowelCount(String str) {
		for(int i=0;i<str.length();i++) {
			char ch=str.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
				vc++;
				
			}
		}
		return vc ;
		
		
		
		
		
	
		
	}

}
