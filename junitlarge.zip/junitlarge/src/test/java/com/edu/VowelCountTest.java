package com.edu;

import static org.junit.Assert.*;


import org.junit.Test;

public class VowelCountTest {
	VowelCount vc;

	@Test
	public void vowelCountTest() {
		vc=new VowelCount();
		
		int r= vc.vowelCount("heyhaii");
		assertEquals(4,r);
		
		
		
		
		
	}
		

}
