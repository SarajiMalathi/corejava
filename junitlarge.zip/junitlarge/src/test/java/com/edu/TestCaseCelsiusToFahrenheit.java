package com.edu;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCaseCelsiusToFahrenheit {
	Celsiustofahrenheit cobj;
	

	@Test
	public void fahrenheit() {
		cobj=new Celsiustofahrenheit();
		double fahrenheit=cobj.celsiusToFahrenheit(35.0);
		assertEquals(95.0,fahrenheit,0.0);
		
		
		
	}
		
}
