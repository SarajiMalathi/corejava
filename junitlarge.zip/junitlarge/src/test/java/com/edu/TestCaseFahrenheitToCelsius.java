package com.edu;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCaseFahrenheitToCelsius {
	Fahrentocelsius fobj;
	

	

	@Test
	public void celcius() {
		 fobj=new Fahrentocelsius();
		double celcius=fobj.fahrenheitToCelsius(27.3);
		assertEquals(-2.611132,celcius,0.0);
		
	}
		

}
