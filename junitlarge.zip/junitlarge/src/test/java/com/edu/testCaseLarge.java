package com.edu;

import static org.junit.Assert.*;


import org.junit.Test;

import com.edu.LargestThreeNumbers;


public class testCaseLarge {
	
	LargestThreeNumbers lobj;
	

	@Test
	public void testCaseLarge() {
		lobj=new LargestThreeNumbers();
		int largest=lobj.largestNumberThree(3,6,1);
		assertEquals(6,largest);
		
		
		
	}

}
