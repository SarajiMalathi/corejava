package edu.com.mapinterface;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class TreeMapMain {

	

	
	private static final Entry<Integer, String> e=null;

	public static void main(String[] args) {
		TreeMap<Integer,String>tp=new TreeMap<Integer,String>();
		tp.put(23452,"chitti");
		tp.put(45672,"paddu");
		tp.put(5679,"anu");
		tp.put(12345,"sai");
		tp.put(2345,"mouni");
		System.out.println(tp);
		for(Entry<Integer,String>e:tp.entrySet());{
			
			System.out.println(e.getKey()+""+ e.getValue());
		}
		
		
	}

}
