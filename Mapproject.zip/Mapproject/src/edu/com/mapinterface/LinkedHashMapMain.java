package edu.com.mapinterface;

import java.util.LinkedHashMap;

public class LinkedHashMapMain {

	public static void main(String[] args) {
		LinkedHashMap<Integer,String> lhp=new LinkedHashMap<Integer,String>();
		lhp.put(234,"chitti");
		lhp.put(123,"sai");
		lhp.put(567,"paddu");
		lhp.put(234,"anu");
		System.out.println(lhp);
		
		

}
}
