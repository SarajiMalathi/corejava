package edu.com.mapinterface;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


public class HashMapmain {

	public static void main(String[] args) {
		HashMap<Integer,String> hp=new HashMap<Integer,String>();
		hp.put(23452,"chitti");
		hp.put(45672,"paddu");
		hp.put(5679,"anu");
		hp.put(12345,"sai");
		hp.put(2345,"mouni");
		System.out.println(hp);
		for(Map.Entry<Integer,String>e:hp.entrySet());{
			Entry<Integer, String> e = null;
			System.out.println(e.getKey() +""+e.getValue());
		}
			 

	}

}
