package edu.com;



import java.util.Scanner;

class RemoveVowel{
	private String s;
	private String s1;
	 public void input() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter string");
		s=sc.nextLine();
		
		}
	 public void removeVowelFunction() {
		 s1="";
		 for(int i=0;i<s.length();i++){
			char ch=s.charAt(i);
			if(ch=='a' || ch=='e'||ch=='i' ||ch=='o'|| ch=='u') {// || ->or
				continue;
			}
			else {
				s1=s1+s.charAt(i);
			}
		
		 }
		 System.out.println("String after removing vowels "+s1);
	 }
}
public class RemoveVowelFunction{
	public static void main(String[] args) {
		RemoveVowel obj=new RemoveVowel();
		obj.input();
		obj.removeVowelFunction();
		
		
	}
	
}

		


		 
	 
	
	 
	







