package edu.com;

public class CheckVowelsReverse {

	public static void main(String[] args) {
		String s="edubridge";
		int count=0;
		System.out.println("no of characters"+s.length());
		System.out.println("to get a character at particular position"+s.charAt(2));
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
				count++;
				
			}
		}
		System.out.println("nof vowels="+count);
		//logic to reverse a string
		for(int i=s.length()-1;i>=0;i--) {
			System.out.println(s.charAt(i));
		}
	}

}
