package edu.com;

public class CheckVowels {

	public static void main(String[] args) {
		String s="edubridge";
		int count=0;
		System.out.println("no of characters"+s.length());
		System.out.println("to get a character at particular position"+s.charAt(2));
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
				count++;
				
			}
		}
		System.out.println("nof vowels="+count);
		
	}

}
