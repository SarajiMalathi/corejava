package edu.com;

public class GetCharFunction {

	public static void main(String[] args) {
		String s1=new String("My Name is malathi");
		char ch[]=new char[10];
		try
		{
			s1.getChars(11, 20, ch, 18);
			System.out.println(ch);
		}
		catch(Exception ex)
		{
			System.out.print(ex);	
		}
		
		
	}
		

	}

