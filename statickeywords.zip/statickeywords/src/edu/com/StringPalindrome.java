package edu.com;

import java.util.Scanner;

public class StringPalindrome {

	public static void main(String[] args) {
		String s,rev="";
		Scanner sc= new Scanner(System.in);
		System.out.println("enter word");
		s=sc.nextLine();
		for(int i=s.length()-1;i>=0;i--) {
			rev=rev+s.charAt(i);
		}
		System.out.println("reverse string"+rev);
		if(s.equals(rev)) {
			System.out.println("string is palindrome");
		}
		else {
			System.out.println("string is not a palindrome");
			
			
		}
		
		
	}

}
