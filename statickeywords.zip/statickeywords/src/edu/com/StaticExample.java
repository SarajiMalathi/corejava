package edu.com;



public class StaticExample {

	static {
		System.out.println("static block executes before main");
	}
	{
		System.out.println("normal block executes before constructor");
	}
	StaticExample(){
		System.out.println("constructor calls an object creation");
	}
	
	
	


	public static void main(String[] args) {
		System.out.println("main method");
		StaticExample od=new StaticExample();
		
	}
		

}


	


