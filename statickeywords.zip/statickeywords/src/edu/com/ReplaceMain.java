package edu.com;

public class ReplaceMain {

	public static void main(String[] args) {
		String s="edubridge india pvt. ltd";
		String rsc=s.replace('a', 'e');
		System.out.println("after replacing "+rsc);
		String rword=s.replace("india", "usa");
		System.out.println("replace word "+rword);
				

	}



	}


