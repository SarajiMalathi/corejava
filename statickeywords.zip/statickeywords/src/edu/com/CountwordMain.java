package edu.com;

import java.util.Scanner;

class wordcount{
	private String sent;
	private int cnt;
	public void inputString() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter sentence");
		sent=sc.nextLine();
	}
	public void wordcountfunction() {
		for(int i=0;i<sent.length();i++) {
			char ch=sent.charAt(i);
			if(ch==' ') {
				cnt++;
				
			}
			
		}
		System.out.println("no of words="+(cnt+1));
	}
}

	public class CountwordMain {

		public static void main(String[] args) {
			wordcount obj=new wordcount();
			obj.inputString();
			obj.wordcountfunction();
			
		}
	}
	
			
			
			
	



		
	
	


 