package edu.com;

import java.util.Scanner;

public class PrintInitialLastName {

	public static void main(String[] args) {
		String name;
		Scanner sc=new Scanner(System.in);

		
		
		System.out.println("Enter full name ");
		name=sc.nextLine();
		System.out.print(name.charAt(0)+".");  //M.
		for(int i=0;i<name.length();i++) {
			char ch=name.charAt(i);
			if(ch==' ') {
				System.out.print(name.charAt(i+1)+"."); //K.
				
				break;
			}
		}
		
		int ind=name.lastIndexOf(' '); 
		System.out.print(name.substring((ind+1)));
		
		
		
	}




	}


