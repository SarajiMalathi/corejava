package edu.com;
	

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class UserValidation
{
	private String uname;
	private String upass;
	public void inputData() throws IOException
	{
		InputStreamReader is=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(is);   
		System.out.println("Enter name");
		uname=br.readLine();
		System.out.println("Enter the password");
		upass=br.readLine();
	}
	public void UserValidate()
	{
		if(uname.equals("Admin") && (upass.equals("admin123")))
		{
			System.out.println("Username and password are equal");
		}
		else
		{
			System.out.println("Invalid user");
		}
	}
	
}

public class StringFunction {

	public static void main(String[] args) throws IOException {
		UserValidation uob=new UserValidation();
		uob.inputData();
		uob.UserValidate();
	
	}


}
