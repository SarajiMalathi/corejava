package edu.com;

public class SubString {
	public static void main(String[] args) {
		String s="malathi";
		System.out.println(s.substring(3));
		System.out.println(s.substring(2,6));
		String str="Mahatma karamchand gandhi";
		System.out.println(str.indexOf('M'));
		System.out.println(str.indexOf('k'));
		System.out.println(str.charAt(0));
		System.out.println(".");
		System.out.println(str.charAt(9));
		System.out.println(".");
		System.out.println(str.substring(20));
		
		
	}

}
