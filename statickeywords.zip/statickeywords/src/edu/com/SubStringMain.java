package edu.com;

public class SubStringMain {

	public static void main(String[] args) {
		String s="edubridge india";
		System.out.println(s.substring(3));
		System.out.println(s.substring(2,6));
	}

}
