package edu.com;
class Addition{
	static int i=1;
	int j;
	Addition(){
		j=1;
	}
	void nonstaticmethod() {
		i=i+1;
		j=j+1;
		System.out.println("static i="+i);
		System.out.println("nonstatic="+j);
	}
	
	
static void staticmethod() {
	i=i+1;
	System.out.println("static i="+i);
	
}
	
}

 

public class StaticMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
