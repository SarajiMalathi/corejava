package edu.com;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

class Employee{
	int eid;
	String ename;
	float esalary;
	public Employee(int eid, String ename, float esalary) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esalary = esalary;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esalary=" + esalary + "]";
	}
	
	

	
		
	}
	



public class EmployeeMain {

	public static void main(String[] args) {
		Employee e1=new Employee(23,"chitti", 8965.34f);
		Employee e2=new Employee(21,"sai", 1298.34f);
		Employee e3=new Employee(12,"mouni", 3298.34f);
		Employee e4=new Employee(28,"rekha", 4298.34f);
		
		ArrayList< Employee> elist=new ArrayList<Employee>();
		elist.add(e1);
		elist.add(e2);
		elist.add(e3);
		elist.add(e4);
		
		//Display data
		
		System.out.println("Employee Records before sorting");
		Iterator<Employee>eit=elist.iterator();
		
		System.out.println("EID\t\tEname\t\tEsalary");
while(eit.hasNext()) {
		Employee eob=eit.next();
		System.out.println(eob.eid+"\t\t"+eob.ename+"\t\t"+eob.esalary);
									
		}


	}

}
