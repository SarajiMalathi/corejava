package edu.com;
import java.util.Iterator;
import java.util.HashSet;



public class HahSetMain {

	public static void main(String[] args) {
		
		HashSet<Integer> hsobj=new HashSet<Integer>();
		 hsobj.add(10);
		 hsobj.add(20);
		 hsobj.add(30);
		 hsobj.add(40);
		 hsobj.add(50);
		 System.out.println(hsobj);
		 Iterator<Integer>it=hsobj.iterator();
		 System.out.println("elements of hashset");
		 while(it.hasNext()) {
			 System.out.println(it.next());
		 }
		 
			 
		 }
		 
		 
		
		
		
	}

	

