package edu.com;

import java.util.Iterator;
import java.util.TreeSet;


public class TreeSetMain {

	public static void main(String[] args) {
		TreeSet<Float>tobj=new TreeSet<Float>();
		tobj.add(1.3f);
		tobj.add(1.4f);
		tobj.add(1.5f);
		tobj.add(1.6f);
		tobj.add(1.7f);
		System.out.println(tobj);
		Iterator<Float>it=tobj.descendingIterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}


		
	}

}
