package edu.com;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;

//Product1
class Product1{
	int productid;
	String productname;
	float productprice;
		
	//no arg constructor 
	public Product1() {
		super();
	}


//with arg constructor
	public Product1(int productid, String productname, float productprice) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
	}

	//generate toString
	@Override
	public String toString() {
		return "Product1 [productid=" + productid + ", productname=" + productname + ", productprice=" + productprice
				+ "]";
	}
	
}

 class ProductSortPid implements Comparator<Product1>{

	@Override
	public int compare(Product1 p1, Product1 p2) {
		if(p1.productid==p2.productid)
			return 0;
		else if(p1.productid> p2.productid)//descending order change sign <
			return 1;
		else 
			return -1;
	}

	
}
 class ProductSortProductPrice implements Comparator<Product1>{

		@Override
		public int compare(Product1 p1, Product1 p2) {
			if(p1.productprice==p2.productprice)
				return 0;
			else if(p1.productprice> p2.productprice)//descending order change sign <
				return 1;
			else 
				return -1;
		}

		
	}
 
class ProductComparatorName implements Comparator<Product1>{

	@Override
	public int compare(Product1 p1, Product1 p2) {
		
		return p1.productname.compareTo(p2.productname); //ascending order
	}
	
}
public class ProductMainApp {

	public static void main(String[] args) {
		Product1 p1=new Product1(1000,"TV", 12000.45f);
		Product1 p2=new Product1(9000,"Oven", 8000.45f);
		Product1 p3=new Product1(5000,"Mixer", 7000.45f);
		
		//add product to LinkedList
		
		LinkedList<Product1>prodlist=new LinkedList<Product1>();
		prodlist.add(p1);
		prodlist.add(p2);
		prodlist.add(p3);
		
		//display product details
		
		Iterator<Product1> pit=prodlist.iterator();
		
		System.out.println("ProductId\tProductName\tProductPrice");
		
		while(pit.hasNext()) {
			 Product1 pob=pit.next();
			 System.out.println(pob.productid+"\t\t"+pob.productname+"\t\t"+pob.productprice);
		}
		
		
		//sort based on product id
		
		System.out.println("Product deatails after sorting based on pid");
       Collections.sort(prodlist,new ProductSortPid());
       
       Iterator<Product1> pit2=prodlist.iterator();
       
       System.out.println("ProductId\tProductName\tProductPrice");
		
		while(pit2.hasNext()) {
			 Product1 pob1=pit2.next();
			 System.out.println(pob1.productid+"\t\t"+pob1.productname+"\t\t"+pob1.productprice);
		}
		
       //Sort based on Product price
       
		System.out.println("Product deatails after sorting based on Product price");
	       Collections.sort(prodlist,new ProductSortProductPrice());
	       
	       Iterator<Product1> pit3=prodlist.iterator();
	       
	       System.out.println("ProductId\tProductName\tProductPrice");
			
			while(pit3.hasNext()) {
				 Product1 pob2=pit3.next();
				 System.out.println(pob2.productid+"\t\t"+pob2.productname+"\t\t"+pob2.productprice);
			}
			
			//Sort based on Product Name
		       
			System.out.println("Product deatails after sorting based on Product name");
		       Collections.sort(prodlist,new ProductSortProductPrice());
		       
		       Iterator<Product1> pit4=prodlist.iterator();
		       
		       System.out.println("ProductId\tProductName\tProductPrice");
				
				while(pit4.hasNext()) {
					 Product1 pob3=pit4.next();
					 System.out.println(pob3.productid+"\t\t"+pob3.productname+"\t\t"+pob3.productprice);
				}
				
			}

}
