package edu.com;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		int num,sum,digit,k;
		num=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		sum=sc.nextInt();
		k=num;
		while(sum>0){
			digit=num%10;
			sum=sum+(digit*digit*digit);
			num=num/10;}
		if(sum==k)
		{
			System.out.println("the is an armstrong number"+k);
		}
		else {
			System.out.println("is an not armstrong number"+k);
			
			
		}
		{
			
		}
		
				

	}

}
