package edu.com;

import java.util.Scanner;

public class PrimeOrNot {

	public static void main(String[] args) {
		int num,i,c=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		num=sc.nextInt();
		for(i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				c++;
			}
			if(c==2) {
				System.out.println("the number is prime"+num);
			}
			else {
				System.out.println("the number is not a prime"+num);
				
			}
			
		}


	}

}
