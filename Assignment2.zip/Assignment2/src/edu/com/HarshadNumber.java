package edu.com;

import java.util.Scanner;

public class HarshadNumber {

	public static void main(String[] args) {
		int sum,num,digit,k;
		sum=0;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter number");
		num=sc.nextInt();
		k=num;
		while(num>0)
		{
			digit=num%10;
			
		}
		

	}

}
