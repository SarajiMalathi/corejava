package edu.com;
import java.util.Scanner;


public class CelciusToFarhenheat {

	public static void main(String[] args) {
		float C,F;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter farhenheat temperature");
		F=sc.nextFloat();
		C=(F-32)*0.5556f;
		System.out.println("enter celcius temperature"+C);
		sc.close();
		

	}

}
