package edu.com;
import java.util.Scanner;
public class GradeMarks {

	public static void main(String[] args) {
		int marks;
		Scanner sc=new Scanner(System.in);
		System.out.print("enter marks");
		marks=sc.nextInt();
		if(marks>=60&&marks<=100)
		{
			System.out.println("enter grade A");
		}
		else if(marks>=60&&marks<=89)
		{
			System.out.println("enter grade B");
		}
		else if(marks>=40&&marks<=59)
		{
			System.out.println("enter grade c");
			
		}
		else if(marks>=0&&marks<=39)
		{
			System.out.println("enter grade D");
			
		}
		

	}

}
