package edu.com;
import java.util.Scanner;
public class LargestOfThreenumber{
	public static void main(String[] args) {
		int num1,num2,num3;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter three number");
		num1=sc.nextInt();
		num2=sc.nextInt();
		num3=sc.nextInt();
		if(num1>num2&&num1>num3)
		{
			System.out.println("enter number1 is greater"+num1);
		}
		else if(num2>num1&&num2>num3)
		{
			System.out.println("enter number2 is greater"+num2);
		}
		else if(num3>num1&&num3>num2)
		{
			System.out.println("enter number3 is greater"+num3);
		}
	}
}