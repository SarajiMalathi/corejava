package edu.com;
import java.util.Scanner;
public class FarhenToCelcius {

	public static void main(String[] args) {
		float F,C;
		Scanner sc=new Scanner(System.in);
		System.out.println("the enter celcius temperature");
		C=sc.nextFloat();
		F=(C*1.8f)+32;
		System.out.println("enter the farhenheat temperature"+F);
		sc.close();
			

	}

}
