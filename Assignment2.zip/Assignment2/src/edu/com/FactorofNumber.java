package edu.com;

import java.util.Scanner;

public class FactorofNumber {

	public static void main(String[] args) {
		int num,i;
		i=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		num=sc.nextInt();
		while(i<=num)
		{
			if(num%i==0)
			{
				System.out.println(""+i);
				i++;
			}
		}
		
		

	}

}
