package assignment1;
public class AreaOfRectangle{
	public static void main(String[] args) {
	int length,breadth,area;
	length=10;
	breadth=20;
	area=length*breadth;
	System.out.println("the area of rectangle"+length+" and "+breadth+" is "+area);
	
	
	}
}

