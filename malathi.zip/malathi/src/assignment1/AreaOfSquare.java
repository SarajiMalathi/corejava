package assignment1;

public class AreaOfSquare {

	public static void main(String[] args) {
		int side,area;
		side=10;
		area=side*side;
		System.out.println("the area of square "+side+" and "+side+" is "+area);
	}
}

	
	
			
				
	


