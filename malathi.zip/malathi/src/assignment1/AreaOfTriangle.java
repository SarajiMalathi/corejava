package assignment1;

public class AreaOfTriangle {

	public static void main(String[] args) {
		float base,height,area;
		base=20;
		height=40;
		area=0.5f*base*height;
		System.out.println("the area of triangle"+base+" and "+height+" is "+area);
		

	}

}
