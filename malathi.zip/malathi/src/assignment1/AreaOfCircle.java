package assignment1;

public class AreaOfCircle {

	public static void main(String[] args) {
		float radius,area;
		radius=100;
		area=3.14159f*radius*radius;
		System.out.println("the area of circle"+radius+" is "+area);
		
		
		
		
		
		


	}

}
