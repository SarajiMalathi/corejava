package com.edu.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcAllOperations {

	
		private static Connection connection;
		private static Statement st;
		private static ResultSet rs;
		static String empname;
	    static int empid;
		static float empsalary;
		static String empdepartment;
	
		private static Scanner sc;
		
		public static void displayRecord() throws SQLException{
			connection=DatabaseConnectionJDBC.getConnection();
			st=connection.createStatement();
			
			String select="select * from employee";
			rs=st.executeQuery(select);
			System.out.println("employee id\temployee name\temployee salary\t employee department");
			while(rs.next()) {
				
			
			System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t"+rs.getFloat(3)+"\t\t"+rs.getString(4));
			}
			
			
		}
		public static void addRecord() throws SQLException {
			connection=DatabaseConnectionJDBC.getConnection();
			st=connection.createStatement();
			sc=new Scanner(System.in);
			System.out.println("enter employee name to add record");
			empname=sc.nextLine();
			System.out.println("enter employee id");
			empid=sc.nextInt();
			System.out.println("enter employee salary");
			empsalary=sc.nextFloat();
			System.out.println("enter employee department");
			empdepartment=sc.next();
			
			String select="select * from employee where  eid="+empid;
			rs=st.executeQuery(select);
			if(!rs.next()) {
				String insert="insert into employee values("+empid+",'"+empname+"',"+empsalary+",'"+empdepartment+"')";
				int i=st.executeUpdate(insert);
				if(i>0) {
					System.out.println("record is inserted successfully");
				}
				else {
					System.out.println("record is not inserted successfully");
				}
			}
			else {
				System.out.println(empid+"already exists");
			}
		}

	public static void updateRecord()throws SQLException{
		connection=DatabaseConnectionJDBC.getConnection();
		st=connection.createStatement();
		sc=new Scanner(System.in);
		System.out.println("enter name to change");
		empname=sc.nextLine();
		System.out.println("enter  id");
		empid=sc.nextInt();
		String select="select * from employee where eid="+empid;
		rs=st.executeQuery(select);
		if(rs.next()) {
			String update="update  employee set ename='"+empname+"' where eid="+empid;
			int rval=st.executeUpdate(update);
			
			if(rval>0) {
				System.out.println("record is updated successfully");
			}
			else {
				System.out.println("record is not updated");
			}
		}
		else {
			System.out.println(empid+"not exists");
			
		}
	}
	public static void deleteRecord() throws Exception {
		connection=DatabaseConnectionJDBC.getConnection();
		st=connection.createStatement();
		sc=new Scanner(System.in);
		System.out.println("enter id");
		empid=sc.nextInt();
		String select="select * from employee where eid="+empid;
		rs=st.executeQuery(select);
		if(rs.next()) {
			String delete="delete from employee where eid="+empid;
			int rval=st.executeUpdate(delete);
			
			if(rval>0) {
				System.out.println("record is deleted successfully");
			}
			else {
				System.out.println("record is not deleted");
			}
		}
		else {
			System.out.println(empid+"employee is not exist to delete record");
		}
	}
}

