package com.edu.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnectionJDBC {
	static Connection con=null;
	public static Connection getConnection() {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/malathidatabase";
		String un="root";
		String pass="root";
		try {
			Class.forName(driver);
			con=DriverManager.getConnection(url,un,pass);
			if(con==null) {
				System.out.println("connection error");
				}
		}
			catch(Exception e) {
				e.printStackTrace();
			}
		return con;
	}
}

