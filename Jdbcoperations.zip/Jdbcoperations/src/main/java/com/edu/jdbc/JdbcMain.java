package com.edu.jdbc;

import java.sql.SQLException;

import java.util.Scanner;

public class JdbcMain {
	
	public static void main(String[] args) throws Exception {
		Scanner sc =new Scanner(System.in);
		while(true) {
			
		

		System.out.println("enter your choice");
		System.out.println("1.display record");
		System.out.println("2.add new record");
		System.out.println("3.update record(name)");
		System.out.println("4.delete record based on id");
		int ch=sc.nextInt();
		switch(ch) {
		case 1:JdbcAllOperations.displayRecord();
		break;
		case 2:JdbcAllOperations.addRecord();
		break;
		case 3:JdbcAllOperations.updateRecord();
		break;
		case 4:JdbcAllOperations.deleteRecord();
		break;
		default: 
			System.out.println("invalid input");
		}
		System.out.println("do you want to continue y\n");
		char choice=sc.next().toLowerCase().charAt(0);
		if(choice!='y') {
			break;
		}
		
	}
	
		
	}
}




			
		
