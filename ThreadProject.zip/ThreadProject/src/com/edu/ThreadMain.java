package com.edu;
class ThreadHello extends Thread{
	@Override
	public void run() {
		for(int i=0;i<=5;i++) {
			System.out.println("inside run"+Thread.currentThread());
			try {
				Thread.sleep(5000);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
				
			}
			
		}
	}
}

public class ThreadMain {

	public static void main(String[] args)throws InterruptedException {
		System.out.println("parent thread"+Thread.currentThread());
		ThreadHello obj=new ThreadHello();
		obj.setName("first");
		System.out.println("first thread is Alive before start()"+obj.isAlive());
		obj.start();
		System.out.println("first thread is Alive after start()"+obj.isAlive());
		obj.join();
		
		System.out.println("first thread is Alive after join()"+obj.isAlive());
		ThreadHello obj1=new ThreadHello();
		obj1.setName("second");
		System.out.println("second thread is Alive before join()"+obj1.isAlive());
		obj1.start();
		System.out.println("second thread is Alive after join()"+obj1.isAlive());
		
		
		
		
		
		
	}

}
