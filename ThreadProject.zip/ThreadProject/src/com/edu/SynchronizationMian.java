package com.edu;
class Table1{
	 synchronized void printTable(int num) {
		for(int i=1;i<=10;i++) {
			System.out.println(num+"x"+i+"="+num*i);
		}
	}
}
class Mythread1 extends Thread{
	Table1 table=new Table1();
	int num;
	public Mythread1(Table1 table,int num) {
		this.table=table;
		this.num=num;
	}

@Override
public void run() {
	table.printTable(num);}

}
	public class SynchronizationMian {

	public static void main(String[] args) {
		Table1 table=new Table1();
		Mythread1 t1= new Mythread1(table,8);
		t1.start();
	}
	}
	
	