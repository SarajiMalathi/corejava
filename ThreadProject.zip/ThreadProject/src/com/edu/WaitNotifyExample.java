package com.edu;
class Sum extends Thread{
	int total;
	@Override
	public void run() {
		System.out.println("inside run method");
		synchronized(this){
			for(int i=0;i<=100;i++) {
				total=total+i;
			}
			notify();
			}}
}



public class WaitNotifyExample {

	public static void main(String[] args) {
		Sum obj=new Sum();
		obj.start();
		synchronized(obj) {
			try {
				System.out.println("before wait method");
				obj.wait();
				System.out.println("total 1 to 100"+obj.total);//0
			}
			catch(InterruptedException e) {
				e.printStackTrace();
				
			
		}
	}
	
		

		}
		

	}


