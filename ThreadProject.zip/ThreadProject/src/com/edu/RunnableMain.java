package com.edu;
class Myclass1 implements Runnable{
	@Override
	public void run() {
		System.out.println("rum method");
		
	}
	
}

public class RunnableMain {

	public static void main(String[] args) {
		Myclass1 obj=new Myclass1();
		Thread tobj=new Thread(obj);
		tobj.start();
		
	}

}
