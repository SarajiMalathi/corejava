package com.edu;

class Pack implements Runnable{
	
	@Override
	public void run() {
		System.out.println("rum method");
	}
}
public class Prioritythread {

	public static void main(String[] args) {
		Pack obj=new Pack();
		Thread tobj=new Thread(obj);
	
		tobj.setName("first method");
		tobj.start();
		Pack obj1=new Pack();
		Thread tobj1=new Thread(obj1);
		tobj1.setPriority(Thread.NORM_PRIORITY);
		tobj1.setPriority(Thread.MAX_PRIORITY);
		tobj1.setPriority(Thread.MIN_PRIORITY);
		
		
		tobj1.setName("second method");
		tobj1.start();
		System.out.println("first method priority"+tobj.getPriority());
		System.out.println("second method priority"+tobj.getPriority());
		System.out.println("second method priority"+tobj.getPriority());
		
	    System.out.println("second method priority"+tobj.getPriority());
}
	}
		
		


