package com.edu;
class Myclass  extends Thread{
	public void run() {
		System.out.println("inside run method"+Thread.currentThread());
	}
}

public class ThreadDemoMain {

	public static void main(String[] args) {
		System.out.println("the thread given JVM"+Thread.currentThread());
		//to execute rum method
		Myclass obj=new Myclass();
		obj.setName("firstthread");
		
		obj.start();
		Myclass obj1=new Myclass();
		obj1.setName("secondthread");
		obj1.start();
		
		
	}

}
