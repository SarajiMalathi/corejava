package com.edu;
class Bank extends Thread{
	int amount=2000;
	synchronized public void deposit(int damount) {
		amount=amount+damount;
		System.out.println("amount after deposit"+amount);
		notify();
	}


	synchronized public void withdraw(int wamount) {
	{
		if(wamount>amount) {
			try {
				System.out.println(" withdraw amount is greater than account balance");
			
				this.wait();
				amount=amount-wamount;
			
			System.out.println("total amount after withdraw amount"+amount);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
				
			}
				
			}
	}
				
			}
		
	}
public class BankMain{
	public static void main(String[] args) {
		Bank bobj=new Bank();
		Thread tobj=new Thread()
		{
			public void run() {
				bobj.withdraw(10000);;
				
			}
		};
		tobj.start();
		Thread tobj1=new Thread()
				{
			public void run()
			{
				bobj.deposit(5000);
			}
				};
				tobj1.start();
				
		
				
			}
				
		
	}



