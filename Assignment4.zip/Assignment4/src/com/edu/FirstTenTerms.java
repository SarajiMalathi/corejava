// to display first ten terms like 1,4,9,16..//
package com.edu;

public class FirstTenTerms {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++) {
			System.out.println(i*i+"");
		}
	}

}
