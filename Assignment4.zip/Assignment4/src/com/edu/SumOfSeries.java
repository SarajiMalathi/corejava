//write a program to find the sum of given series S=a2+a2/2+a2/3...+a2/10//
package com.edu;


import java.util.Scanner;

public class SumOfSeries {

	public static void main(String[] args) {
		int a,n=10,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of a");
		a=sc.nextInt();
		a=a*a;
		for(int i=1;i<=10;i++) {
			sum=sum+a/i;
			
		}
		System.out.println("sum="+sum);

	}

}
