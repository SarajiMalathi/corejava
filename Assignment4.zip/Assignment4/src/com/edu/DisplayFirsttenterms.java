//to display first 10 terms//
package com.edu;

public class DisplayFirsttenterms {

	public static void main(String[] args) {
		for(int i=10;i<=100;i+=10) {
			System.out.println(i+"");
		}
	}

}
