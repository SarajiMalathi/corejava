//find sum of series s=1!+2!+....+n!//
package com.edu;

import java.util.Scanner;

public class SeriesOfSum {

	public static void main(String[] args) {
		int fact,s=0,n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of N");
		n=sc.nextInt();
		for(int i=1;i<=n;i++) {
			fact=1;
			for(int j=1;j<=i;j++) {
				fact*=j;
				s=fact;
				
			}
			System.out.println("the value of sum series is"+s);
	}
	
	}
}

	
		 
