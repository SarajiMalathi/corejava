package com.edu;

public class Calculator {
	int ans;
	public int add(int a, int b) {
		 ans=a+b;
		return ans;
		
	}


	public int sub(int a, int b) {
		 ans=a-b;
		return ans;
	}
	
public int mul(int a, int b) {
	 ans=a*b;
	return ans;
}
}

	

