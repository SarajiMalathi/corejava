package com.edu;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {
	Calculator cobj;

	@Test
	public void addtestcase() {
		cobj=new Calculator();
		int a=cobj.add(6,9);
		assertEquals(15,a);
		
	}
		


public void subtestcase() {
	cobj=new Calculator();
	int a=cobj.sub(6,9);
	assertEquals(-3,a);
	
}
public void multestcase() {
	cobj=new Calculator();
	int a=cobj.mul(6,9);
	assertEquals(54,a);
}
}


	

