package edu.com;
import java.util.*;
public class QueueInterface{
	public static void main(String[] args) {
		Queue queue=new PriorityQueue();
		queue.offer(10);
		queue.offer(20);
		queue.offer(30);
		queue.offer(40);
		System.out.println("queue elements are"+queue);
		System.out.println("head elements are"+queue.element());
		System.out.println("head elements again"+queue.peek());
		queue.remove();

		
		System.out.println("elements after head removal"+queue);
		queue.poll();
		System.out.println("elements after one more head removal"+queue);

	}
}