package edu.com;

import java.util.ArrayDeque;
import java.util.Deque;

public class DequeueInterface {

	public static void main(String[] args) {
		Deque deque=new ArrayDeque();
		deque.addFirst(10);
		deque.addLast(20);
		deque.offerFirst(30);
		deque.offerLast(40);
		deque.push(2);
		System.out.println("elements of deque"+deque);
		System.out.println(" first elements "+deque.getFirst());
		System.out.println(" last elements "+deque.getLast());
		System.out.println(" first elements "+deque.peekFirst());
		System.out.println(" last elements "+deque.peekLast());
		System.out.println(" remove first elements "+deque.pop());
		System.out.println(" remove one more first elements "+deque.pollFirst());
		System.out.println(" remove last elements "+deque.pollLast());
		System.out.println(" remove one more first elements "+deque.removeFirst());
		System.out.println("remove one more last elements"+deque.removeLast());
		
		
		
		
	}

}
