package demovaraible;

public class Substraction { 
	public static void main(String args[]) {
	
	float fval1,fval2,fans;
	fval1=10;
	fval2=20;
	fans=fval2-fval1;
	System.out.println("the differenceof"+fval2+" and "+fval1+" is "+fans);
	
	
}
}
