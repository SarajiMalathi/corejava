package demovaraible;

public class Division {

	public static void main(String[] args) {
		int num1,num2,ans;
		num1=100;
		num2=200;
		ans=num1/num2;
		System.out.println("the division of "+num2+" and "+num1+" is "+ans);
		

	}

}
