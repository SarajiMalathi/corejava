package demovaraible;

public class Multiplication {

	public static void main(String[] args) {
		float fval1,fval2,fans;
		fval1=100;
		fval2=300;
		fans=fval2*fval1;
		System.out.println("the multiplication of"+fval2+" and "+fval1+" is "+fans);
		
		
		
		
		
		
		
		
		

	}

}
