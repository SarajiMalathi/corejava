package edu.com;

import java.util.Scanner;

public class MenuDriven {

	public static void main(String[] args) {
		int ar[];
		int n,sum=0,op,temp,pos=-1,mid=0,low,high,key;
		float avg;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the array size");
		n=sc.nextInt();
		ar=new int[n];
		System.out.println("enter the array elements");
		for(int i=0;i<ar.length;i++) {
			ar[i]=sc.nextInt();
		}
		System.out.println("------menu-----");
		System.out.println("1.find minimum");
		System.out.println("2.find maximum");
		System.out.println("3.find sum");
		System.out.println("4.find average");
		System.out.println("5.sort the elements  ");
		System.out.println("6.linear search");
		System.out.println("7.binary search");
		System.out.println("enter your option");
		op=sc.nextInt();
		switch(op) {
		case 1:
			int min=ar[0];
			for(int i=0;i<ar.length;i++) {
				if(ar[i]<min) {
					min=ar[i];}
			}
			System.out.println("the smallest element"+min);
			break;
		case 2:
			int max=ar[0];
			for(int i=0;i<ar.length;i++) {
				if(ar[i]>max) {
					max=ar[i];
				}
			}
			System.out.println("the largest element"+max);
			break;
		case 3:
			for(int i=0;i<ar.length;i++) {
				sum=sum+ar[i];
			}
			System.out.println("the sum of element"+sum);
			break;
		case 4:
			for(int i=0;i<ar.length;i++) {
				sum=sum+ar[i];
			}
			avg=(float)sum/ar.length;
			System.out.println("the average"+avg);
			break;
		case 5:
			for(int i=0;i<ar.length;i++) {
				for(int j=0;j<ar.length-1-i;j++) {
					if(ar[j]>ar[j+1])
					{
						temp=ar[j];
						ar[j]=ar[j+1];
						ar[j+1]=temp;
					}
				}
			}
			System.out.println("the sorted array is:");
			for(int i=0;i<ar.length;i++) {
				System.out.println(ar[i]+"");
			}
			break;
		case 6:
			System.out.println("enter key elements");
			key=sc.nextInt();
			for(int i=0;i<ar.length;i++) {
				if(key==ar[i])
				{
					pos=i;
					break;
				}
				if(pos>=0)
				{
					System.out.println("successful search");
					System.out.println(key+"found at positon"+(pos+1));
				}
				else {
					System.out.println("unsuccessful search");
					System.out.println(key+" not found ");}
				break;
			}
			
				
			
			
				
				case 7:
					System.out.println("enter key element");
					key=sc.nextInt();
					for(int i=0;i<n;i++)
					{
						for(int j=0;j<n-1-i;j++)
						{
							if(ar[j]>ar[j+1])
							{
								temp=ar[j];
								ar[j]=ar[j+1];
								ar[j+1]=temp;
							}
						}
					}
					low=0;
					high=n-1;
					while(low<=high)
					{
						mid=(low+high)/2;
						if(ar[mid]==key) {
							pos=mid;
							break;
						}
						else if(key<ar[mid]) {
							high=mid-1;
						}
						else
						{
							low=mid+1;
						}
					}
					if(pos>=0) {
						System.out.println("successful search");
						System.out.println(key+"found at position"+(mid+1));
					}
					else {
						System.out.println("unsuccessful search");
						System.out.println(key+"not found");
					}
					break;
					default:
						System.out.println("invalid option");
		}
		sc.close();
		
					
							
							}
					
					
				
			
			
		
		
	}


